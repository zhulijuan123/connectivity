DIconnectivity-eDMN README
[15th Nov 2020]

######################################################
DIconnectivity-eDMN.R runs under the linux platform.
######################################################
First you need to create a work directory:
/home/DIconnectivity-eDMN/

######################################################
Then you can run DIconnectivity-eDMN.R with the following command:
1. The example data
nohup R --slave --vanilla </home/DIconnectivity-eDMN/examples/DIconnectivity-eDMN.R &
2. The data in our study
nohup R --slave --vanilla </home/DIconnectivity-eDMN/DIconnectivity-eDMN.R &

============
Data folder
============
The Data folder contains 2 subfolders.
1. R_input folder;
2. R_output folder.

=================
1. R_input folder
=================
The folder contains 3 files: 
(1) added diabetes_disease genes.txt: 
the genes of T1D, T2D, vitamin D and diseases;
(2) hsa.GO.BP.txt:
the BP information file;
(3) human network.txt:
human PPI network file.

==================
2. R_output folder
==================
The folder contains the result files: 
(1) T1D_expand_subnet_interactions_adgi.txt(i=1,2,...,10):
The number of interactions between expanded T1D genes and expanded diseases&vitamin D genes(the expansion fold=i);
(2)  T2D_expand_subnet_interactions_adgi.txt(i=1,2,...,10):
The number of interactions between expanded T2D genes and expanded diseases&vitamin D genes(the expansion fold=i).



