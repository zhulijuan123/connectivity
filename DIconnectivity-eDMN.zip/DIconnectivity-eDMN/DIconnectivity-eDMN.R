#################################################################################################################
setwd("/home/DIconnectivity-eDMN")
##################################################################### 
### General
DATA.FOLD <- paste0("./Data/")
NETWORK.FOLD <- paste0(DATA.FOLD, "R_input/")
if(!file.exists(NETWORK.FOLD)){dir.create(NETWORK.FOLD)} 
NETWORK.FOLD1 <- paste0(DATA.FOLD, "R_output/")
if(!file.exists(NETWORK.FOLD1)){dir.create(NETWORK.FOLD1)} 

###
eMN.FOLD <- paste0(NETWORK.FOLD1, "expand BP network/")
if(!file.exists(eMN.FOLD)){dir.create(eMN.FOLD)} 
###
eDN1.FOLD <- paste0(NETWORK.FOLD1, "expand T1D network_adg/")
if(!file.exists(eDN1.FOLD)){dir.create(eDN1.FOLD)} 
###
eDN2.FOLD <- paste0(NETWORK.FOLD1, "expand T2D network_adg/")
if(!file.exists(eDN2.FOLD)){dir.create(eDN2.FOLD)} 
###
eDD.FOLD <- paste0(NETWORK.FOLD1, "expand disease network_adg/")
if(!file.exists(eDD.FOLD)){dir.create(eDD.FOLD)} 



##################################################################################################################
###the genes of TD and diseases
addg=list()
n=0
dgbp<- file(paste0(NETWORK.FOLD,'added diabetes_disease genes.txt'), "r")
line=readLines(dgbp,n=1)
while( length(line) != 0 ) {
   n=n+1
   addg[[n]]=line  
   line=readLines(dgbp,n=1)

}
close(dgbp)

##################################################################### 
###
fadge=list()
for(i in 1:length(addg)){
fadge[[i]]=unlist(strsplit(addg[[i]], "\t"))
}

##################################################################### 
###
tng1=fadge[[1]]
tng2=fadge[[2]]
zjbg=list()
for(i in 1:(length(fadge)-2)){
zjbg[[i]]=fadge[[i+2]]
}


##################################################################### 
###
bpjg=list()
m=0
bp<- file(paste0(NETWORK.FOLD,'hsa.GO.BP.txt'), "r")
line=readLines(bp,n=1)
while(length(line) != 0 ) {
   m=m+1
   bpjg[[m]]=line  
   line=readLines(bp,n=1)

}
close(bp)

###
fqu=list()
symbollist=list() 
bpg=list()
for(i in 1:length(bpjg)){
fqu[[i]]=unlist(strsplit(bpjg[[i]], "\t"))
symbollist[[i]]=fqu[[i]][1]
bpg[[i]]=fqu[[i]][3:length(fqu[[i]])]
}
symbollist=unlist(symbollist)


##################################################################### 
###select BPs
sbpg=list()
n=0
for(i in 1:length(bpg)){
if(length(bpg[[i]])>=30&length(bpg[[i]])<=500){
n=n+1
sbpg[[n]]=bpg[[i]]
 }
}

##################################################################### 
###map select BPs
ppn<- read.delim(paste0(NETWORK.FOLD,'human network.txt'),header=F,stringsAsFactors=F)[,c(1,3)]
ppn<- ppn[ppn[,1]!=ppn[,2],]

###
nawz1=which(is.na(ppn[,1])==TRUE)
nawz2=which(is.na(ppn[,2])==TRUE)
nawz=union(nawz1,nawz2)
ppn=ppn[-nawz,]

###
uhppg=unique(unlist(ppn))
length(uhppg)

###
bpng=list()
for(i in 1:length(sbpg)){
bpng[[i]]=intersect(uhppg,sbpg[[i]])
}



##################################################################################################################
###random walk on subnet
ljjz=matrix(0,length(uhppg),length(uhppg))
for(i in 1:length(uhppg)){
wz1=which(ppn[,1]==uhppg[i])
hzg1=ppn[wz1,2]
wz2=which(ppn[,2]==uhppg[i])
hzg2=ppn[wz2,1]
hzg=c(hzg1,hzg2)
hzgwz=match(hzg,uhppg)
ljjz[i,hzgwz]=1
ljjz[hzgwz,i]=1
}

###
bljz=matrix(0,length(uhppg),length(uhppg))
for(i in 1:length(uhppg)){
bljz[,i]=ljjz[,i]/sum(ljjz[,i])
}

###
sp=list()
r=0.7
for(i in 1:length(bpng)){
pwz=match(bpng[[i]],uhppg)
p=matrix(0,length(uhppg),1)
p[pwz]=1/length(bpng[[i]])
pxh1=p
pxh2=(1-r)*bljz%*%pxh1+r*p
while(max(abs(pxh2-pxh1))>10^(-6)){
pxh1=pxh2
pxh2=(1-r)*bljz%*%pxh2+r*p
 }
sp[[i]]=pxh2
}

###
for(s in 1:length(sp)){
write.table(sp[[s]],file= paste0(NETWORK.FOLD1,'expand BP network/expand BP network probability',s,'.txt'), row.names=F, col.names=F, quote=F, sep='\n')
}

##################################################################### 
###expand subnets
N=3
kg=list()
for(i in 1:length(sp)){
psp=sort(unlist(sp[[i]]),decreasing=TRUE)
ks=min(N*length(bpng[[i]]),500)
gwz=match(psp[1:ks],unlist(sp[[i]]))
kg[[i]]=uhppg[gwz]
}

###
for(s in 1:length(kg)){
write.table(kg[[s]],file= paste0(NETWORK.FOLD1,'expand BP network/expand BP gene',s,'.txt'), row.names=F, col.names=F, quote=F, sep='\n')
}



##################################################################################################################
###random walk on TD and diseases
###T1D
kbtg=list()
for(i in 1:length(kg)){
kbtg[[i]]=intersect(tng1,kg[[i]])
}
###T2D
kbtg2=list()
for(i in 1:length(kg)){
kbtg2[[i]]=intersect(tng2,kg[[i]])
}

###diseases
kbdg=list()
for(i in 1:length(zjbg)){
kbdg[[i]]=list()
for(j in 1:length(kg)){
kbdg[[i]][[j]]=intersect(zjbg[[i]],kg[[j]])
 }
}

##################################################################### 
###RWR expand
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
cl <- makeCluster(8)
registerDoParallel(cl)

###
fun <- function(s){
###
bphz=ppn[(ppn[,1]%in% kg[[s]])&(ppn[,2]%in% kg[[s]]),]

###
bpfile<-paste0(NETWORK.FOLD1,'expand BP network/expand BP subnetwork interaction',s,'.txt')
sink(bpfile,append = T)
for(j in 1:nrow(bphz))
{
cat(bphz[j,1])
cat('\t')
cat(bphz[j,2])
cat('\n') 
}  
sink() 
}

###
bpn<- foreach(s=1:length(kg)) %dopar% fun(s)
stopCluster(cl)

##################################################################### 
###RWR expand on TD and diseases
bppn=list()
for(s in 1:length(kg)){
bppn[[s]]<- read.delim(paste0(NETWORK.FOLD1,'expand BP network/expand BP subnetwork interaction',s,'.txt'),header=F,stringsAsFactors=F)
}

###
r=0.7
###
cl <- makeCluster(8)
registerDoParallel(cl)
###
fun <- function(i){
###
ubpg=unique(unlist(bppn[[i]]))
ljjz=matrix(0,length(ubpg),length(ubpg))
for(i1 in 1:length(ubpg)){
wz1=which(bppn[[i]][,1]==ubpg[i1])
hzg1=bppn[[i]][wz1,2]
wz2=which(bppn[[i]][,2]==ubpg[i1])
hzg2=bppn[[i]][wz2,1]
hzg=c(hzg1,hzg2)
hzgwz=match(hzg,ubpg)
ljjz[i1,hzgwz]=1
ljjz[hzgwz,i1]=1
}
###
bljz=matrix(0,length(ubpg),length(ubpg))
for(i2 in 1:length(ubpg)){
bljz[,i2]=ljjz[,i2]/sum(ljjz[,i2])
}

###T1D
kpt=list()
tpwz=match(kbtg[[i]],ubpg)
tp=matrix(0,length(ubpg),1)
tp[tpwz]=1/length(kbtg[[i]])

pxh1=tp
pxh2=(1-r)*bljz%*%pxh1+r*tp
while(max(abs(pxh2-pxh1))>10^(-6)){
pxh1=pxh2
pxh2=(1-r)*bljz%*%pxh2+r*tp
}
kpt=pxh2
###
write.table(kpt,file= paste0(NETWORK.FOLD1,'expand T1D network_adg/expand T1D network based on expand BP subnetwork',i,'.txt'), row.names=F, col.names=F, quote=F, sep='\n')

###T2D
kpt2=list()
tpwz=match(kbtg2[[i]],ubpg)
tp=matrix(0,length(ubpg),1)
tp[tpwz]=1/length(kbtg2[[i]])

pxh1=tp
pxh2=(1-r)*bljz%*%pxh1+r*tp
while(max(abs(pxh2-pxh1))>10^(-6)){
pxh1=pxh2
pxh2=(1-r)*bljz%*%pxh2+r*tp
}
kpt2=pxh2
###
write.table(kpt2,file= paste0(NETWORK.FOLD1,'expand T2D network_adg/expand T2D network based on expand BP subnetwork',i,'.txt'), row.names=F, col.names=F, quote=F, sep='\n')

###diseases
kpd=list()
for(s in 1:length(zjbg)){
pwz=match(kbdg[[s]][[i]],ubpg)
p=matrix(0,length(ubpg),1)
p[pwz]=1/length(kbdg[[s]][[i]])

pxh1=p
pxh2=(1-r)*bljz%*%pxh1+r*p
while(max(abs(pxh2-pxh1))>10^(-6)){
pxh1=pxh2
pxh2=(1-r)*bljz%*%pxh2+r*p
  }
kpd[[s]]=pxh2
###
write.table(kpd[[s]],file= paste0(NETWORK.FOLD1,'expand disease network_adg/expand disease network based on expand BP subnetwork',i,'_',s,'.txt'), row.names=F, col.names=F, quote=F, sep='\n')
 }
}

###
bpdn<- foreach(i=1:length(bppn)) %dopar% fun(i)
stopCluster(cl)

##################################################################### 
###T1D
ktgv=list()
for(i in 1:length(bppn)){
ktgv[[i]]<- read.delim(paste0(NETWORK.FOLD1,'expand T1D network_adg/expand T1D network based on expand BP subnetwork',i,'.txt'),header=F,stringsAsFactors=F)
}
###T2D
ktgv2=list()
for(i in 1:length(bppn)){
ktgv2[[i]]<- read.delim(paste0(NETWORK.FOLD1,'expand T2D network_adg/expand T2D network based on expand BP subnetwork',i,'.txt'),header=F,stringsAsFactors=F)
}

###diseases
kdgv=list()
for(s in 1:length(zjbg)){
kdgv[[s]]=list()
for(i in 1:length(bppn)){
kdgv[[s]][[i]]<- read.delim(paste0(NETWORK.FOLD1,'expand disease network_adg/expand disease network based on expand BP subnetwork',i,'_',s,'.txt'),header=F,stringsAsFactors=F)
 }
}


#########################################################################################################################
###DIconnectivity-eDMN
###T1D
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
cl <- makeCluster(8)
registerDoParallel(cl)
fun <- function(N){
###
kktg=list()
kkbdg=list()
ltd=matrix(0,length(zjbg),length(bppn))
###
for(s in 1:length(zjbg)){
kkbdg[[s]]=list()
kktg[[s]]=list()

###
for(i in 1:length(bppn)){
if(length(kbtg[[i]])>0&length(kbdg[[s]][[i]])>0){

pdv=unlist(kdgv[[s]][[i]])
ubpg=unique(unlist(bppn[[i]]))
bcg=setdiff(kg[[i]],ubpg)
nubpg=union(ubpg,bcg)
npdv=c(pdv,rep(0,length(bcg)))
xpdv=rep(0,length(npdv))
gtwz=match(kbtg[[i]],nubpg)
if(length(gtwz)>0){
xpdv[gtwz]=npdv[gtwz]+sqrt((length(nubpg)-length(kbtg[[i]]))/length(kbtg[[i]]))
xpdv[-gtwz]=npdv[-gtwz]-sqrt(length(kbtg[[i]])/(length(nubpg)-length(kbtg[[i]])))
}

###
psp=sort(xpdv,decreasing=TRUE)
ks=min(N*length(kbdg[[s]][[i]]),length(nubpg))
if(ks>0){
gwz=match(psp[1:ks],xpdv)
kkbdg[[s]][[i]]=nubpg[gwz]
} 

###
ptv=unlist(ktgv[[i]])
ubpg=unique(unlist(bppn[[i]]))
bcg=setdiff(kg[[i]],ubpg)
nubpg=union(ubpg,bcg)
nptv=c(ptv,rep(0,length(bcg)))
xptv=rep(0,length(nptv))
gtwz=match(kbdg[[s]][[i]],nubpg)
if(length(gtwz)>0){
xptv[gtwz]=nptv[gtwz]+sqrt((length(nubpg)-length(kbdg[[s]][[i]]))/length(kbdg[[s]][[i]]))
xptv[-gtwz]=nptv[-gtwz]-sqrt(length(kbdg[[s]][[i]])/(length(nubpg)-length(kbdg[[s]][[i]])))
 }
 
###
psp=sort(xptv,decreasing=TRUE)
ks=min(N*length(kbtg[[i]]),length(nubpg))
if(ks>0){
gwz=match(psp[1:ks],xptv)
kktg[[s]][[i]]=nubpg[gwz]
}

hz1=bppn[[i]][(bppn[[i]][,1]%in% kktg[[s]][[i]])&(bppn[[i]][,2]%in%kkbdg[[s]][[i]]),]
hz2=bppn[[i]][(bppn[[i]][,2]%in% kktg[[s]][[i]])&(bppn[[i]][,1]%in%kkbdg[[s]][[i]]),]
ltd[s,i]=nrow(rbind(hz1,hz2))

}
}
}

###
write.table(ltd,file= paste0(NETWORK.FOLD1,'T1D_expand_subnet_interactions_adg',N,'.txt'), row.names=F, col.names=F, quote=F, sep='\t')
}

###
khz<- foreach(N=1:10) %dopar% fun(N)
stopCluster(cl)



#####################################################################
###DIconnectivity-eDMN 
###T2D
cl <- makeCluster(8)
registerDoParallel(cl)
fun <- function(N){
###
kktg=list()
kkbdg=list()
ltd=matrix(0,length(zjbg),length(bppn))
###
for(s in 1:length(zjbg)){
kktg[[s]]=list()
kkbdg[[s]]=list()

###
for(i in 1:length(bppn)){
if(length(kbtg2[[i]])>0&length(kbdg[[s]][[i]])>0){

pdv=unlist(kdgv[[s]][[i]])
ubpg=unique(unlist(bppn[[i]]))
bcg=setdiff(kg[[i]],ubpg)
nubpg=union(ubpg,bcg)
npdv=c(pdv,rep(0,length(bcg)))
xpdv=rep(0,length(npdv))
gtwz=match(kbtg2[[i]],nubpg)
if(length(gtwz)>0){
xpdv[gtwz]=npdv[gtwz]+sqrt((length(nubpg)-length(kbtg2[[i]]))/length(kbtg2[[i]]))
xpdv[-gtwz]=npdv[-gtwz]-sqrt(length(kbtg2[[i]])/(length(nubpg)-length(kbtg2[[i]])))
}

###
psp=sort(xpdv,decreasing=TRUE)
ks=min(N*length(kbdg[[s]][[i]]),length(nubpg))
if(ks>0){
gwz=match(psp[1:ks],xpdv)
kkbdg[[s]][[i]]=nubpg[gwz]
} 

###
ptv=unlist(ktgv2[[i]])
ubpg=unique(unlist(bppn[[i]]))
bcg=setdiff(kg[[i]],ubpg)
nubpg=union(ubpg,bcg)
nptv=c(ptv,rep(0,length(bcg)))
xptv=rep(0,length(nptv))
gtwz=match(kbdg[[s]][[i]],nubpg)
if(length(gtwz)>0){
xptv[gtwz]=nptv[gtwz]+sqrt((length(nubpg)-length(kbdg[[s]][[i]]))/length(kbdg[[s]][[i]]))
xptv[-gtwz]=nptv[-gtwz]-sqrt(length(kbdg[[s]][[i]])/(length(nubpg)-length(kbdg[[s]][[i]])))
 }
 
###
psp=sort(xptv,decreasing=TRUE)
ks=min(N*length(kbtg2[[i]]),length(nubpg))
if(ks>0){
gwz=match(psp[1:ks],xptv)
kktg[[s]][[i]]=nubpg[gwz]
}

hz1=bppn[[i]][(bppn[[i]][,1]%in% kktg[[s]][[i]])&(bppn[[i]][,2]%in%kkbdg[[s]][[i]]),]
hz2=bppn[[i]][(bppn[[i]][,2]%in% kktg[[s]][[i]])&(bppn[[i]][,1]%in%kkbdg[[s]][[i]]),]
ltd[s,i]=nrow(rbind(hz1,hz2))

}
}
}

###
write.table(ltd,file= paste0(NETWORK.FOLD1,'T2D_expand_subnet_interactions_adg',N,'.txt'), row.names=F, col.names=F, quote=F, sep='\t')
}

###��ʼ����
khz<- foreach(N=1:10) %dopar% fun(N)
#��������
stopCluster(cl)





